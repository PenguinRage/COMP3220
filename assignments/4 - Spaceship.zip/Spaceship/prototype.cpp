#include "prototype.h"

Prototype::Prototype()
{

}
